$(document).ready(function(){
	// your code here


		
	// n = 0;
	// $('body').click(function(){
	// 	n = n + 1;	
	// 	$('#pass').css('opacity', n/20);
	// });

	// $('body').mousemove(function(e){
	// 	$('#pass').css('opacity', + (e.pageY) / 10000);
	// });

});