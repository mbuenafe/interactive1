
$('body').children().each(function () {
	// replace the '@' sign with a '$' sign

	$(this).html( $(this).html().replace(/\$11\.14/g,'RG3') );
	$(this).html( $(this).html().replace(/\$11\.18/g,'RG3') );
	$(this).html( $(this).html().replace(/\$11\.34/g,'RG3') );
	$(this).html( $(this).html().replace(/\$15\.95/g,'RG4') );
	$(this).html( $(this).html().replace(/\$189\.00/g,'RG48') );
	$(this).html( $(this).html().replace(/\$12\.95/g,'RG3') );
	$(this).html( $(this).html().replace(/\$6\.49/g,'RG2') );
	$(this).html( $(this).html().replace(/\$16\.00/g,'RG4') );
	$(this).html( $(this).html().replace(/\$133\.04/g,'RG33') );
	$(this).html( $(this).html().replace(/\$17\.59/g,'RG5') );
	$(this).html( $(this).html().replace(/\$9\.22/g,'RG2') );
	$(this).html( $(this).html().replace(/\$37\.95/g,'RG3') );
	$(this).html( $(this).html().replace(/\$7\.54/g,'RG2') );
	$(this).html( $(this).html().replace(/\$3\.75/g,'RG1') );
	$(this).html( $(this).html().replace(/\$12\.50/g,'RG3') );
	$(this).html( $(this).html().replace(/\$19\.99/g,'RG5') );
	$(this).html( $(this).html().replace(/\$24\.59/g,'RG6S') );
	$(this).html( $(this).html().replace(/\$9\.99/g,'RG3') );
	$(this).html( $(this).html().replace(/\$33\.79/g,'RG9') );
	$(this).html( $(this).html().replace(/\$25\.99/g,'RG7') );
	$(this).html( $(this).html().replace(/\$118\.99/g,'RG30') );
	$(this).html( $(this).html().replace(/\$39\.99/g,'RG10') );

});





//
// // replace text in the page when it loads
// $('body').children().each(function () {
//
// // replace the '@' sign with a '$' sign
// $(this).html( $(this).html().replace(/$/g,'WOW!') );
// });
//

// // replace images when the page loads
// $('img').attr('src', 'http://i.dailymail.co.uk/i/pix/2015/09/15/13/2C554FAA00000578-3235219-image-m-70_1442319933551.jpg');
//

// // when you click on an image hide it using CSS
// $('img').click(function() {
// 	$(this).addClass('hide');
// });



// // when you click on the page 'body' apply .gradient to it from the CSS
// $('body').click(function() {
// 	$(this).addClass('gradient');
// });
//
// $('#hplogo').addClass('rotate');
